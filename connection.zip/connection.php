<?php
$db_host = 'localhost';
$db_username = 'root';
$db_password = '';
$db_name = 'data';

// Establish database connection
$conn = new mysqli($db_host, $db_username, $db_password, $db_name);

// Check connection
if ($conn->connect_error) 
{
    die("Connection failed: " . $conn->connect_error);
}
else{
    die("New recored successfully created");
}

if (isset($_POST['confirmRegistration'])) {
    $date = $_POST['visit_date'];
    $time = $_POST['current_time'];
    $fname = $_POST['first_name'];
    $lname = $_POST['last_name'];
    $adults = $_POST['adults'];
    $children = $_POST['children'];
    $pnumber = $_POST['phone_number'];
    $town = $_POST['town'];
    $aadhar = $_POST['aadhar'];

    // Prepare and bind
    $stmt = $conn->prepare("INSERT INTO book (visit_date, current_time, first_name, last_name, adults, children, phone_number, town, aadhar) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sssssssss", $date, $time, $fname, $lname, $adults, $children, $pnumber, $town, $aadhar);

    // Set parameters and execute
    $stmt->execute();

    // Check if the query was successful
    if ($stmt->affected_rows > 0) {
        echo "New record created successfully";
    } else {
        echo "Error: " . $stmt->error;
    }

    // Close statement and connection
    $stmt->close();
    $conn->close();
}
?>